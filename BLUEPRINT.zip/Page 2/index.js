function changeColor(n) {
  const button = document.querySelector(`#click${n}`);
   if (button.style.backgroundColor === "#fc8d06") {
    button.style.backgroundColor = 'white';
  }
  else {
    button.style.backgroundColor = '#fc8d06';
  }
}

function openInfo(n) {
  document.querySelector(`#stuff${n++}`) = document.querySelector("#box")
}

function toOptions() {
  const button1 = document.querySelector("#click1");
      const computedStyle1 = window.getComputedStyle(button1);
      const backgroundColor1 = computedStyle1.backgroundColor;
      if (backgroundColor1 === "rgb(252, 141, 6)") {
        window.location.href = "/Page%203/page3.html";
      }
  const button0 = document.querySelector("#click0");
      const computedStyle0 = window.getComputedStyle(button0);
      const backgroundColor0 = computedStyle0.backgroundColor;
      if (backgroundColor0 === "rgb(252, 141, 6)") {
    window.location.href = "/page%205%20(stuco)/page5.html";
      }
  const button3 = document.querySelector("#click3");
      const computedStyle3 = window.getComputedStyle(button3);
      const backgroundColor3 = computedStyle3.backgroundColor;
      if (backgroundColor3 === "rgb(252, 141, 6)") {
    window.location.href = "/Page%206/page6.html";
      }
  const button2 = document.querySelector("#click2");
      const computedStyle2 = window.getComputedStyle(button2);
      const backgroundColor2 = computedStyle2.backgroundColor;
      if (backgroundColor2 === "rgb(252, 141, 6)") {
  window.location.href = "/page%205%20(stuco)/page5.html";
      }
  const button4 = document.querySelector("#click4");
      const computedStyle4 = window.getComputedStyle(button4);
      const backgroundColor4 = computedStyle4.backgroundColor;
      if (backgroundColor4 === "rgb(252, 141, 6)") {
  window.location.href = "/page%205%20(stuco)/page5.html";
      }
  const button5 = document.querySelector("#click5");
      const computedStyle5 = window.getComputedStyle(button5);
      const backgroundColor5 = computedStyle5.backgroundColor;
      if (backgroundColor5 === "rgb(252, 141, 6)") {
  window.location.href = "/Page%203/page3.html";
      }
  const button6 = document.querySelector("#click6");
      const computedStyle6 = window.getComputedStyle(button6);
      const backgroundColor6 = computedStyle6.backgroundColor;
      if (backgroundColor6 === "rgb(252, 141, 6)") {
  window.location.href = "/Page%203/page3.html";
      }
  const button7 = document.querySelector("#click7");
      const computedStyle7 = window.getComputedStyle(button7);
      const backgroundColor7 = computedStyle7.backgroundColor;
      if (backgroundColor7 === "rgb(252, 141, 6)") {
  window.location.href = "/Page%203/page3.html";
      }
  const button8 = document.querySelector("#click8");
      const computedStyle8 = window.getComputedStyle(button8);
      const backgroundColor8 = computedStyle8.backgroundColor;
      if (backgroundColor8 === "rgb(252, 141, 6)") {
  window.location.href = "/page%205%20(stuco)/page5.html";
      }
  const button9 = document.querySelector("#click9");
    const computedStyle9 = window.getComputedStyle(button9);
    const backgroundColor9 = computedStyle9.backgroundColor;
    if (backgroundColor9 === "rgb(252, 141, 6)") {
  window.location.href = "/Page%206/page6.html";
    }
  const button10 = document.querySelector("#click10");
    const computedStyle10 = window.getComputedStyle(button10);
    const backgroundColor10 = computedStyle9.backgroundColor;
    if (backgroundColor10 === "rgb(252, 141, 6)") {
  window.location.href = "/Page%206/page6.html";
    }
  const button11 = document.querySelector("#click11");
      const computedStyle11 = window.getComputedStyle(button11);
      const backgroundColor11 = computedStyle11.backgroundColor;
      if (backgroundColor11 === "rgb(252, 141, 6)") {
  window.location.href = "/page%205%20(stuco)/page5.html";
      }
}