function changeColor(n) {
  const button = document.querySelector(`#click${n}`);
   if (button.style.backgroundColor === "#fc8d06") {
    button.style.backgroundColor = 'white';
  }
  else {
    button.style.backgroundColor = '#fc8d06';
  }
}

function openInfo(n) {
  document.querySelector(`#stuff${n++}`) = document.querySelector("#box")
}